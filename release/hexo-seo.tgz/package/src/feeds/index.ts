import Hexo from 'hexo';
import { Args } from 'hexo/dist/hexo/index-d';
import { NodeJSLikeCallback } from 'hexo/dist/types';
import nunjucks from 'nunjucks';
import path from 'path';
import { normalizePath, writefile } from 'sbg-utility';

export function generateFeeds(this: Hexo, _args: Args, callback?: NodeJSLikeCallback<any>) {
  try {
    const config = this.config;
    const templateDir = path.join(__dirname, 'views');
    const sourceXML = path.join(templateDir, 'rss.xml');
    const env = nunjucks.configure(templateDir, {
      noCache: true,
      autoescape: false,
      throwOnUndefined: false,
      trimBlocks: false,
      lstripBlocks: false
    });
    const result = env.render(sourceXML, {
      siteTitle: 'Your Site Title',
      siteUrl: 'https://www.yoursite.com',
      siteDescription: 'Your site description here.',
      language: 'en-us',
      lastBuildDate: 'Sat, 26 Oct 2024 10:00:00 +0000',
      pubDate: 'Sat, 26 Oct 2024 10:00:00 +0000',
      ttl: 1800,
      items: [
        {
          title: 'Example Post Title',
          link: 'https://www.yoursite.com/example-post',
          description: 'This is an example description for the post.',
          authorEmail: 'author@example.com',
          authorName: 'Author Name',
          category: 'Category Name',
          pubDate: 'Sat, 26 Oct 2024 09:00:00 +0000',
          guid: 'https://www.yoursite.com/example-post'
        }
        // additional items as needed
      ]
    });
    const paths = [path.join(config.source_dir, 'rss.xml'), path.join(config.public_dir, 'rss.xml')];
    paths.forEach((file) => writefile(file, JSON.stringify(result)));
    hexo.log.info(
      `[hexo-seo] Local search saved to ${paths.map((file) => normalizePath(file).replace(normalizePath(hexo.base_dir), '')).join(', ')}.`
    );
    callback(null);
  } catch (error) {
    callback(error);
  }
}
